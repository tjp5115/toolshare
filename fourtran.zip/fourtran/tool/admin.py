from django.contrib import admin
from tool.models import Tool

admin.site.register(Tool)