from django.contrib import admin
from userProfile.models import UserProfile

admin.site.register(UserProfile)
